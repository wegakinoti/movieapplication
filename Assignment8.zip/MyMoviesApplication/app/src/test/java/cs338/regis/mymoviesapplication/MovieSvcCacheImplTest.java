package cs338.regis.mymoviesapplication;

import org.junit.Test;
import static org.junit.Assert.*;

import cs338.regis.mymoviesapplication.model.Movie;
import cs338.regis.mymoviesapplication.model.MovieSvcCacheImpl;
import  java.util.List;


public class MovieSvcCacheImplTest {

    @Test
    public void testCRUD(){
        //Look at topic 3 material and look at singleton pattern, this will go into the MovieSvcCacheImpl
        //Complete the test, follow the info online

        MovieSvcCacheImpl svc = MovieSvcCacheImpl.getInstance();

        Movie movie = new Movie();
        movie.setMovieName("Inception");
        movie.setDirectorName("Christopher Nolan");
        movie.setMainActor("Dicaprio");
        movie.setMovieDescription("Thriller");

        List<Movie> movies = svc.retrieveAll();
        assertNotNull(movies);
        int initialSize = movies.size();

        //test the create
        movie = svc.create(movie);
        assertNotNull(movie);

        //test the retrieve
        movies = svc.retrieveAll();
        int size = movies.size();
        assertEquals(initialSize + 1, size);

        //test the update
        movie.setDirectorName("Nikola");
        movie = svc.update(movie);
        assertNotNull(movie);
        assertEquals("Nikola", movie.getDirectorName());

        //test the delete
        movie = svc.delete(movie);
        assertNotNull(movie);
        movies = svc.retrieveAll();
        size = movies.size();
        assertEquals(initialSize,size);


    }
}
