package cs338.regis.mymoviesapplication;

import android.content.Context;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import java.util.List;

import cs338.regis.mymoviesapplication.model.Movie;
import cs338.regis.mymoviesapplication.model.MovieSvcSQLiteImpl;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

public class MovieSvcSQLiteImplTest{

    @Test
    public void testCRUD(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("cs338.regis.mymoviesapplication", appContext.getPackageName());

        MovieSvcSQLiteImpl svc = MovieSvcSQLiteImpl.getInstance(appContext);
        assertNotNull(svc);

        List<Movie> list = svc.retrieveAll();
        assertNotNull(list);
        int initialSize = list.size();
        Movie m = new Movie();
        m.setMovieName("Inception");
        m.setMovieRate("R");
        m.setDirectorName("Christopher Nolan");
        m.setRunTime("140 minutes");
        m.setYearReleased("2012");
        m.setMainActor("Leonardo DiCaprio");
        m.setMovieDescription("Thriller");
        m.setUserRate("10");

        m = svc.create(m);
        assertNotNull(m);

        int id = m.getId();
        assertNotEquals(0,id);

        list = svc.retrieveAll();
        assertEquals(initialSize + 1, list.size());

        m.setMovieName("Dark Knight");
        m = svc.update(m);
        assertNotNull(m);

        m = svc.delete(m);
        assertNotNull(m);

        list = svc.retrieveAll();
        assertEquals(initialSize, list.size());


    }



}

