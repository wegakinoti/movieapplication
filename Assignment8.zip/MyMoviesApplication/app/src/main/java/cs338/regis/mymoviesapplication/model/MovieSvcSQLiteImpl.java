package cs338.regis.mymoviesapplication.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MovieSvcSQLiteImpl extends SQLiteOpenHelper implements IMovieSvc {

    private static final String TAG = "MovieSvcSQLiteImpl";
    private static final String DBNAME = "movies.db";
    private static final int DBVERSION = 1;
    private final String CREATE_MOVIE_TABLE = "CREATE TABLE movie (id INTEGER PRIMARY KEY AUTOINCREMENT, " + "movieName TEXT NOT NULL, " +
            "movieRate TEXT NOT NULL, directorName TEXT NOT NULL, runTime TEXT, yearReleased TEXT, mainActor TEXT, movieDescription TEXT, userRate TEXT)";
    private final String DROP_MOVIE_TABLE = "DROP TABLE IF EXISTS movies";
    private static MovieSvcSQLiteImpl instance = null;

    public static MovieSvcSQLiteImpl getInstance(Context context){
        if (instance == null){
            instance = new MovieSvcSQLiteImpl(context);
        }
        return instance;
    }

    private MovieSvcSQLiteImpl(Context context){
        super(context, DBNAME, null, DBVERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db){
        Log.i(TAG, "onCreate");
        db.execSQL(CREATE_MOVIE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        Log.i(TAG, "onUpgrade");
        db.execSQL(DROP_MOVIE_TABLE);
        onCreate(db);
    }

    public Movie create(Movie m){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("movieName", m.getMovieName());
        values.put("movieRate", m.getMovieRate());
        values.put("directorName", m.getDirectorName());
        values.put("runTime", m.getRunTime());
        values.put("yearReleased", m.getYearReleased());
        values.put("mainActor", m.getMainActor());
        values.put("movieDescription", m.getMovieDescription());
        values.put("userRate", m.getUserRate());

        db.insert("movie", null, values);

        //get the last inserted id
        Cursor cursor = db.rawQuery("SELECT last_insert_rowid()", null);
        cursor.moveToFirst();
        int id = cursor.getInt(0);
        m.setId(id);
        cursor.close();
        db.close();
        return m;
    }
    public List<Movie> retrieveAll(){
        List <Movie> movies =  new ArrayList<Movie>();
        String columns [] = {"id", "movieName","movieRate", "directorName","runTime", "yearReleased", "mainActor", "movieDescription", "userRate"};
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("movie", columns, null,null,null,null,null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            Movie m = getMovie(cursor);
            movies.add(m);
            cursor.moveToNext();
        }
        db.close();

        return movies;
    }

    private Movie getMovie(Cursor cursor){
        Movie m = new Movie();
        m.setId(cursor.getInt(0));
        m.setMovieName(cursor.getString(1));
        m.setMovieRate(cursor.getString(2));
        m.setDirectorName(cursor.getString(3));
        m.setRunTime(cursor.getString(4));
        m.setYearReleased(cursor.getString(5));
        m.setMainActor(cursor.getString(6));
        m.setMovieDescription(cursor.getString(7));
        m.setUserRate(cursor.getString(8));

        return m;
    }

    public Movie update(Movie m){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("movieName", m.getMovieName());
        values.put("movieRate", m.getMovieRate());
        values.put("directorName",m.getDirectorName());
        values.put("runTime",m.getRunTime());
        values.put("yearReleased", m.getYearReleased());
        values.put("mainActor", m.getMainActor());
        values.put("movieDescription", m.getMovieDescription());
        values.put("userRate",m.getUserRate());


        db.update("movie", values, "id = " + m.getId(),null);
        db.close();
        return m;
    }
    public Movie delete(Movie m){
        SQLiteDatabase db = getWritableDatabase();
        db.delete("movie", "id = " + m.getId(),null);
        db.close();
        return m;

    }
}

// ADD A RUNTIME  Category FOR THE MOVIES AS A FIELD WAY WAY WAY WAY BACK
//Make the tests
// Email Sjodin about the one line error for the test, also text Sam