package cs338.regis.mymoviesapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;

public class GalleryActivity extends AppCompatActivity {
    private final String TAG ="GalleryActivity";
    private FirebaseStorage firebaseStorage = null;
    private StorageReference gsReference = null;
    private ImageView image = null;
    private static int currentImageId = 1;

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_gallery);

        image = findViewById(R.id.galleryImgId);
        initFireBaseStorage();
    }

    private void initFireBaseStorage(){
        firebaseStorage = FirebaseStorage.getInstance();
        gsReference = firebaseStorage.getReferenceFromUrl("gs://mymoviecs338project.appspot.com/gallery/favmovieslogo.png");
        image = findViewById(R.id.myfavmovieslogo);
        try{
            final File localFile = File.createTempFile("images", "png");
            gsReference.getFile(localFile).addOnSuccessListener(
                    new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            try{
                                Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                                image.setImageBitmap(bitmap);
                                image.setMinimumHeight(700);
                                image.setMinimumWidth(700);

                            }catch(Exception e){
                                Log.i(TAG,"*** onSuccess EXCEPTION ***" + e.getMessage());
                            }
                            Log.i(TAG, "*** onSuccess Completed ***");
                        }
                    }
            ).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.i(TAG, "*** initFireBaseStorage onFailure Exception " + e.getMessage());
                }
            });
        }catch (Exception e){
            Log.i(TAG, "*** initFireBaseStorage onFailure EXCEPTION" + e.getMessage());
        }

    }

    public void next(View view){
        try{
            if (currentImageId<=7){
                currentImageId++;
            }else{
                currentImageId = 1;
            }
            String url = "gs://mymoviecs338project.appspot.com/gallery/image" + currentImageId + ".jpg";
            gsReference = firebaseStorage.getReferenceFromUrl(url);
            final File localFile = File.createTempFile("images", "png");
            image = findViewById(R.id.galleryImgId);
            gsReference.getFile(localFile).addOnSuccessListener(
                    new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            try{
                                Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                                image.setImageBitmap(bitmap);
                                image.setMinimumHeight(700);
                                image.setMinimumWidth(700);
                            }catch(Exception e){
                                Log.i(TAG,"*** NEXT EXCEPTION ***" + e.getMessage());
                            }
                            Log.i(TAG, "*** NEXT Completed");
                        }
                    }
            ).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.i(TAG, "*** NEXT onFailure Exception " + e.getMessage());
                }
            });
        } catch(Exception e){
            Log.i(TAG,"*** NEXT" + e.getMessage());
        }
    }

    public void previous(View view){
        try{
            if (currentImageId<=1){
                currentImageId = 6;
            }else{
                currentImageId--;
            }
            image = findViewById(R.id.galleryImgId);
            String url = "gs://mymoviecs338project.appspot.com/gallery/image" + currentImageId + ".jpg";
            gsReference = firebaseStorage.getReferenceFromUrl(url);
            final File localFile = File.createTempFile("images", "png");
            gsReference.getFile(localFile).addOnSuccessListener(
                    new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            try{
                                Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                                image.setImageBitmap(bitmap);
                                image.setMinimumHeight(700);
                                image.setMinimumWidth(700);
                                Log.i(TAG, "*** PREVIOUS Completed ***");
                            }catch(Exception e){
                                Log.i(TAG,"*** PREVIOUS EXCEPTION ***" + e.getMessage());
                            }
                        }
                    }
            ).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.i(TAG, "*** PREVIOUS onFailure Exception " + e.getMessage());
                }
            });
        } catch(Exception e){
            Log.i(TAG,"*** NEXT" + e.getMessage());
        }
    }
}
