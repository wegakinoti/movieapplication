package cs338.regis.mymoviesapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import cs338.regis.mymoviesapplication.model.Note;

public class NoteListActivity extends AppCompatActivity {
    private final String TAG = "NoteListActivity";
    private ListView notesListView;
    private DatabaseReference firebaseDB;

    @Override
    protected void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_notelist);

        notesListView = (ListView) findViewById(R.id.noteListListId);
        firebaseDB = FirebaseDatabase.getInstance().getReference();

    }

    @Override
    public void onResume(){
        super.onResume();

        firebaseDB.child("notes").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final List<Note> notes = new ArrayList<Note>();
                for (DataSnapshot noteDataSnapshot : dataSnapshot.getChildren()){
                    Note note = noteDataSnapshot.getValue(Note.class);
                    notes.add(note);
                }
                ArrayAdapter adapter = new ArrayAdapter<Note>(getApplicationContext(), android.R.layout.simple_list_item_1, notes);
                notesListView.setAdapter(adapter);
                notesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Log.i(TAG,"*** onItemClickListener");
                        Note note = notes.get(position);
                        Intent intent = new Intent(NoteListActivity.this, NoteDetailActivity.class);
                        intent.putExtra("note", notes.get(position));
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "onCancelled", databaseError.toException());
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.notesactionbar,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        Intent intent;
        switch (item.getItemId()){
            case (R.id.action_new_note):
                intent = new Intent(this, NoteDetailActivity.class);
                startActivity(intent);
                break;
            default:
                super.onOptionsItemSelected(item);
                break;
        }
        return true;
    }

}
