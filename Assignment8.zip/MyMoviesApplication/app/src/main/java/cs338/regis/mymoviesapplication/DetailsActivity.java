package cs338.regis.mymoviesapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cs338.regis.mymoviesapplication.model.IMovieSvc;
import cs338.regis.mymoviesapplication.model.Movie;
import cs338.regis.mymoviesapplication.model.MovieSvcCacheImpl;
import cs338.regis.mymoviesapplication.model.MovieSvcSQLiteImpl;

public class DetailsActivity extends AppCompatActivity {

    private EditText movieNameFld;
    private EditText movieRateFld;
    private EditText directorNameFld;
    private EditText runTimeFld;
    private EditText yearReleasedFld;
    private EditText mainActorFld;
    private EditText movieDescripFld;
    private EditText userRateFld;

    private Button leftBtn;
    private Button rightBtn;
    private Movie movie;
    private IMovieSvc movieSvc;

    private void populateMovie(Movie movie){
        movie.setMovieName(movieNameFld.getText().toString());
        movie.setMovieRate(movieRateFld.getText().toString());
        movie.setDirectorName(directorNameFld.getText().toString());
        movie.setRunTime(runTimeFld.getText().toString());
        movie.setYearReleased(yearReleasedFld.getText().toString());
        movie.setMainActor(mainActorFld.getText().toString());
        movie.setMovieDescription(movieDescripFld.getText().toString());
        movie.setUserRate(userRateFld.getText().toString());


    }

    private boolean checkFields(){
        if (movieNameFld.getText().toString().equals("")){
            Toast.makeText(this,"Movie name is required", Toast.LENGTH_LONG).show();
            return false;
        }
        if (movieRateFld.getText().toString().equals("")){
            Toast.makeText(this,"Movie name is required", Toast.LENGTH_LONG).show();
        }
        if (directorNameFld.getText().toString().equals("")){
            Toast.makeText(this,"Director name is required", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        movieNameFld = findViewById(R.id.movie_nameId);
        movieRateFld = findViewById(R.id.movie_rateID);
        directorNameFld = findViewById(R.id.movie_directorID);
        runTimeFld = findViewById(R.id.runTime_ID);
        yearReleasedFld = findViewById(R.id.movie_yearID);
        mainActorFld = findViewById(R.id.movie_ActorID);
        movieDescripFld = findViewById(R.id.movie_descriptionID);
        userRateFld = findViewById(R.id.userRateId);


        leftBtn = findViewById(R.id.save_buttonID);
        rightBtn = findViewById(R.id.cancel_buttonID);

        movie = (Movie) getIntent().getSerializableExtra("movie");

        if (movie != null){
            movieNameFld.setText(movie.getMovieName());
            movieRateFld.setText(movie.getMovieRate());
            directorNameFld.setText(movie.getDirectorName());
            runTimeFld.setText(movie.getRunTime());
            yearReleasedFld.setText(movie.getYearReleased());
            mainActorFld.setText(movie.getMainActor());
            movieDescripFld.setText(movie.getMovieDescription());
            userRateFld.setText(movie.getUserRate());

            leftBtn.setText("Update");
            rightBtn.setText("Delete");
        }
        movieSvc = MovieSvcSQLiteImpl.getInstance(getApplicationContext());
    }


    public void cancelDelete(View view){
        if (movie != null){
            IMovieSvc movieSvc = MovieSvcSQLiteImpl.getInstance(getApplicationContext());
            movieSvc.delete(movie);
            Toast.makeText(this, "Movie has been deleted", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    public void saveUpdate(View view){

        if (!checkFields()) return;

        IMovieSvc movieSvc = MovieSvcSQLiteImpl.getInstance(getApplicationContext());
        if(movie == null) {
            movie = new Movie();
            populateMovie(movie);
            movieSvc.create(movie);
            Toast.makeText(this, "Movie has ben saved", Toast.LENGTH_SHORT).show();

        }
        else{
            populateMovie(movie);
            movieSvc.update(movie);
            Toast.makeText(this, "Movie has ben saved", Toast.LENGTH_SHORT).show();

        }
        finish();
    }






}
