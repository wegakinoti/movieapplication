package cs338.regis.mymoviesapplication.model;

import java.io.Serializable;

public class Movie implements Serializable {

    private int id;

    private String movieName;

    private String directorName;

    private String runTime;

    private String movieRate;

    private String yearReleased;

    private String mainActor;

    private String movieDescription;

    private String userRate;



    @Override
    public String toString(){
        return movieName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieRate() {
        return movieRate;
    }

    public void setMovieRate(String movieRate) {
        this.movieRate = movieRate;
    }

    public String getDirectorName() {
        return directorName;
    }

    public void setDirectorName(String directorName) {
        this.directorName = directorName;
    }

    public String getYearReleased() {
        return yearReleased;
    }

    public void setYearReleased(String yearReleased) {
        this.yearReleased = yearReleased;
    }

    public String getRunTime(){return runTime;}

    public void setRunTime(String runTime){this.runTime = runTime;}

    public String getMainActor() {
        return mainActor;
    }

    public void setMainActor(String mainActor) {
        this.mainActor = mainActor;
    }

    public String getMovieDescription() {
        return movieDescription;
    }

    public void setMovieDescription(String movieDescription) {
        this.movieDescription = movieDescription;
    }

    public String getUserRate(){return userRate;};

    public void setUserRate(String userRate){this.userRate = userRate;}


}
