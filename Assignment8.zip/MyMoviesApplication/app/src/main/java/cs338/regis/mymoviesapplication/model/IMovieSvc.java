package cs338.regis.mymoviesapplication.model;

import java.util.List;

public interface IMovieSvc {
    public Movie create(Movie m);
    public List<Movie> retrieveAll();
    public Movie update(Movie m);
    public Movie delete(Movie m);

}

