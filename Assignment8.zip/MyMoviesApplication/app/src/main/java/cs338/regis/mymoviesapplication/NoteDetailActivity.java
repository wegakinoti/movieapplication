package cs338.regis.mymoviesapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import cs338.regis.mymoviesapplication.model.Note;

public class NoteDetailActivity extends AppCompatActivity {
    private final String TAG = "NoteDetailActivity";
    private Note note = null;
    private EditText titleFld = null;
    private EditText descFld = null;
    private Button saveBtn = null;
    private Button cancelBtn = null;
    private DatabaseReference firebaseDB = null;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notelistdetails);

        firebaseDB = FirebaseDatabase.getInstance().getReference();
        titleFld = (EditText)findViewById(R.id.noteItem1id);
        descFld = (EditText)findViewById(R.id.noteItem2Id);
        saveBtn = (Button)findViewById(R.id.noteSaveBtnID);
        cancelBtn = (Button)findViewById(R.id.noteCancelBtnID);
        Intent intent = getIntent();
        note = (Note) intent.getSerializableExtra("note");
        if (note != null){
            Log.i(TAG, "Note: " + note.getUid() );
            titleFld.setText(note.getTitle());
            descFld.setText((note.getDescription()));
            saveBtn.setText("Update");
            cancelBtn.setText("Delete");
        }
    }

    public void saveUpdate(View view){
        if(checkFields()){
            Note note = new Note();
            note.setUid(firebaseDB.child("notes").push().getKey());
            note.setTitle(titleFld.getText().toString());
            note.setDescription(descFld.getText().toString());
            firebaseDB.child("notes").child(note.getUid()).setValue(note);
        }
        else{
            note.setTitle(titleFld.getText().toString());
            note.setDescription(descFld.getText().toString());
            firebaseDB.child("notes").child(note.getUid()).setValue(note);
        }
        finish();

    }

    public void cancelDelete(View view){
        if(note == null){
            finish();
        }
        else{
            firebaseDB.child("notes").child(note.getUid()).removeValue();
            finish();

        }
    }

    private boolean checkFields(){
        if(titleFld.getText().toString().equals("") || descFld.getText().toString().equals("")){
            Toast.makeText(this, "*** All Fields need a value ***", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }



}
