package cs338.regis.mymoviesapplication.model;

import java.util.ArrayList;
import java.util.List;

public class MovieSvcCacheImpl implements IMovieSvc {
    private List<Movie> movies = new ArrayList();
    private int nextId = 0;
    private MovieSvcCacheImpl(){
        initList();
    }

    private void initList(){
        Movie movie = new Movie();
        movie.setMovieName("Inception");
        movie.setDirectorName("Christopher Nolan");
        movie.setRunTime("120 minutes");
        movie.setYearReleased("2012");
        movie.setMainActor("Leonardo Dicaprio");
        movie.setMovieDescription("Thriller");
        movie.setMovieRate("10");
        movies.add(movie);
    }

    private static MovieSvcCacheImpl instance = new MovieSvcCacheImpl();

    public static MovieSvcCacheImpl getInstance(){
        return instance;
    }

    public Movie create(Movie m){
        m.setId(++nextId);
        movies.add(m);
        return m;
    }
    public List<Movie> retrieveAll(){
        return movies;
    }
    public Movie update(Movie m){
        int size = movies.size();
        for (int i = 0; i < size; i++){
            if(movies.get(i).getId() == m.getId()){
                movies.set(i,m);
                break;
            }
        }
        return m;
    }
    public Movie delete(Movie m){
        int size = movies.size();
        for(int i = 0; i <size; i++){
            if (movies.get(i).getId() == m.getId()){
                movies.remove(i);
                break;
            }
        }
        return m;
    }





}
