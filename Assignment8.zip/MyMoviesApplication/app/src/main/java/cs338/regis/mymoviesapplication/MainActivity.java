package cs338.regis.mymoviesapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import cs338.regis.mymoviesapplication.model.IMovieSvc;
import cs338.regis.mymoviesapplication.model.Movie;
import cs338.regis.mymoviesapplication.model.MovieSvcSQLiteImpl;
import cs338.regis.mymoviesapplication.model.Note;
import cs338.regis.mymoviesapplication.service.BackUpService;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MoviesActivity";
    private ListView listView;
    private ListView notesListView;
    private IMovieSvc svc;
    private ArrayAdapter adapter;
    private FirebaseAuth mAuth;
    private Task task;
    private boolean login;
    private DatabaseReference mDatabase;
    private MyBroadcastReciever br;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG, "**** On Create ****");
        listView = (ListView) findViewById(R.id.mainListViewId);
        svc = MovieSvcSQLiteImpl.getInstance(getApplicationContext());
        initFirebase();
        br = new MyBroadcastReciever();
        IntentFilter filter = new IntentFilter();
        filter.addAction("cs338.regis.mymoviesapplication.EXPORT_DATABASE");
        this.registerReceiver(br, filter);
    }

    @Override
    public void onStart(){
        super.onStart();
        Log.i(TAG, "*** On Start ****");
    }

    @Override
    public void onResume(){
        super.onResume();
        Log.i(TAG, "*** On Resume ***");
        final List<Movie> list = svc.retrieveAll();
        adapter = new ArrayAdapter<Movie>(this,android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView <?> parent, View view, int position, long id){
                        Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                        Movie movie = list.get(position);
                        intent.putExtra("movie", movie);

                        startActivity(intent);
                    }
                }
        );

    }

    @Override
    public void onPause(){
        super.onPause();
        Log.i(TAG, "*** On Pause ***");
    }

    @Override
    public void onStop(){
        super.onStop();
        Log.i(TAG, "*** On Stop ***");
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.i(TAG, "*** On Destroy ****");
    }

    public void displayDetails(View view){
        Intent intent = new Intent(this,DetailsActivity.class);
        startActivity(intent);
    }

    public void displayAboutUs(View view){
        Intent intent = new Intent(this, AboutUsActivity.class);
        startActivity(intent);
    }

    public void displayContactUs(View view){
        Intent intent = new Intent(this, ContactUsActivity.class);
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //Inflating the menu in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.appbar,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        Intent intent;
        switch(item.getItemId()){
            case R.id.action_new:
                Log.i(TAG, "action ADD was clicked");
                intent = new Intent(this, DetailsActivity.class);
                startActivity(intent);
                break;
            case R.id.action_contactus:
                Log.i(TAG, "action Contact Us was clicked");
                intent = new Intent(this, ContactUsActivity.class);
                startActivity(intent);
                break;
            case R.id.action_about:
                Log.i(TAG, "action About was clicked");
                intent = new Intent(this, AboutUsActivity.class);
                startActivity(intent);
                break;
            case R.id.action_notes:
                Log.i(TAG, "action Notes was clicked");
                intent = new Intent(this, NoteListActivity.class);
                startActivity(intent);
                break;
            case R.id.action_gallery:
                Log.i(TAG,"action Gallery was clicked");
                intent = new Intent(this, GalleryActivity.class);
                startActivity(intent);
                break;
            case R.id.action_export:
                Log.i(TAG, "action Export was clicked");
                Intent intent4 = new Intent(this, BackUpService.class);
                startService(intent4);
                break;
            default:
                super.onOptionsItemSelected(item);
                break;
        }
        return true;
    }
    private void initFirebase(){
        Log.i(TAG, "** initFirebase Database Started **");
        mAuth = FirebaseAuth.getInstance();
        mAuth.signInAnonymously().addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Log.i(TAG, "*** Login Successful ***");
                    login = true;

                }
                else{
                    login = false;
                    Log.i(TAG,"*** Login Failed ***");

                }

            }
        });


    }

    public class MyBroadcastReciever extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, intent.getStringExtra("message"),Toast.LENGTH_LONG).show();

        }
    }
    /* Optional
     private void initFirebaseList(){
        mDatabase = FirebaseDatabase.getInstance().getReference();
        if (mDatabase == null){
            Log.i(TAG,"initFireBaseList: mDatabase is Null");
            return;
        }

        mDatabase.child("notes").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final List<Note> notes = new ArrayList<Note>();
                for (DataSnapshot noteDataSnapshot: dataSnapshot.getChildren()){
                    Note note = noteDataSnapshot.getValue(Note.class);
                    notes.add(note);
                }
                ArrayAdapter adapter = new ArrayAdapter<Note>(getApplicationContext(), android.R.layout.simple_list_item_1, notes);
                notesListView.setAdapter(adapter);
                notesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Log.i(TAG,"** On item Click");
                        Note note = notes.get(position);
                        Log.i(TAG,"*** Note " + note.getUid());
                        Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                        intent.putExtra("note", notes.get(position));
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("loadPost: onCancelled", databaseError.toException());
            }
        });
    }
     */

}
