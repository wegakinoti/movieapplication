package cs338.regis.mymoviesapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class LaunchActivity extends AppCompatActivity {

    private static final String TAG = "LaunchActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
    }

    @Override
     protected void onResume(){
        super.onResume();

        try{
            Thread.sleep(3000);
        }
        catch(Exception e){
            Log.i(TAG,"** EXCEPTION ** " + e.getMessage());
            

        }
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }


    /*This weeks Assignment is the user interface for all the screens

     */
}
