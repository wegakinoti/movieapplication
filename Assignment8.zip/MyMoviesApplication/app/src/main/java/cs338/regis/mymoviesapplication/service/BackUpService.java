package cs338.regis.mymoviesapplication.service;

import android.app.IntentService;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.UUID;


public class BackUpService extends IntentService {
    public BackUpService(){
        super("BackupService");
    }

    private final String TAG = "BackupService";

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        try{
            exportSqliteDatabase();
        } catch(Exception e){
            Log.i(TAG,"EXCEPTION " + e.getMessage());
        }
    }

    protected void exportSqliteDatabase(){
        Log.i(TAG,"*** Entering Database ***");
        File data = Environment.getDataDirectory();
        String dbPath = "/data/data/cs338.regis.mymoviesapplication/databases/movies.db";
        Uri file = Uri.fromFile(new File (dbPath));
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageRef = firebaseStorage.getReference();
        StorageReference ref = storageRef.child("database/" + UUID.randomUUID().toString());
        ref.putFile(file).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Intent intent = new Intent();
                intent.setAction("cs338.regis.mymoviesapplication.EXPORT_DATABASE");
                intent.putExtra("message", "Database exported to Firebase");
                sendBroadcast(intent);
                Log.i(TAG, "onSuccessListener");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.i(TAG, "onFailureListener");
            }
        });
        Log.i(TAG, "exiting exportSQLiteDatabase");
    }
}
